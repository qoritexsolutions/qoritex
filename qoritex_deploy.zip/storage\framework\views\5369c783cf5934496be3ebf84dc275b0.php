

<?php $__env->startSection('title', 'Leadership Team'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h2>Leadership Team</h2>
            <a href="<?php echo e(route('admin.leadership.create')); ?>" class="btn btn-primary btn-sm">
                <i class="fas fa-plus"></i> Add Leader
            </a>
        </div>
        <div class="card-body">
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Name</th>
                            <th>Position</th>
                            <th>Order</th>
                            <th>Featured</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $leaders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div
                                        style="width: 50px; height: 50px; background: var(--gradient-primary); border-radius: 12px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                                        <?php if($leader->photo): ?>
                                            <img src="<?php echo e(asset('storage/' . $leader->photo)); ?>" alt="<?php echo e($leader->name); ?>"
                                                style="width: 100%; height: 100%; object-fit: cover;">
                                        <?php else: ?>
                                            <i class="<?php echo e($leader->icon); ?>" style="color: white; font-size: 1.25rem;"></i>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td><strong><?php echo e($leader->name); ?></strong></td>
                                <td><?php echo e($leader->position); ?></td>
                                <td><?php echo e($leader->order); ?></td>
                                <td>
                                    <?php if($leader->is_featured): ?>
                                        <span class="badge badge-warning"><i class="fas fa-star"></i> Featured</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">No</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo e($leader->is_active ? 'success' : 'danger'); ?>">
                                        <?php echo e($leader->is_active ? 'Active' : 'Inactive'); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <a href="<?php echo e(route('admin.leadership.edit', $leader)); ?>" class="action-btn"
                                            title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.leadership.destroy', $leader)); ?>" method="POST"
                                            onsubmit="return confirm('Are you sure you want to delete this leader?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="action-btn delete" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" style="text-align: center; color: var(--gray); padding: 3rem;">
                                    No leadership members found. <a href="<?php echo e(route('admin.leadership.create')); ?>">Add your
                                        first leader</a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\qorit\Desktop\qoritex\techcompany\resources\views/admin/leadership/index.blade.php ENDPATH**/ ?>