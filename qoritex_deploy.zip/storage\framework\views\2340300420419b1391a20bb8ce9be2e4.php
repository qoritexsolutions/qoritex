

<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>All Services</h2>
        <a href="<?php echo e(route('admin.services.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Add Service
        </a>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Icon</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Order</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div style="width: 40px; height: 40px; background: var(--gradient-primary); border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                                <i class="<?php echo e($service->icon ?? 'fas fa-cog'); ?>" style="color: white;"></i>
                            </div>
                        </td>
                        <td><strong><?php echo e($service->title); ?></strong></td>
                        <td><?php echo e(Str::limit($service->description, 50)); ?></td>
                        <td><?php echo e($service->order); ?></td>
                        <td>
                            <span class="badge badge-<?php echo e($service->is_active ? 'success' : 'danger'); ?>">
                                <?php echo e($service->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td>
                            <div class="actions">
                                <a href="<?php echo e(route('admin.services.edit', $service)); ?>" class="action-btn" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.services.destroy', $service)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this service?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="action-btn delete" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--gray); padding: 3rem;">
                            No services found. <a href="<?php echo e(route('admin.services.create')); ?>">Add your first service</a>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($services->hasPages()): ?>
        <div class="pagination">
            <?php echo e($services->links()); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\qorit\Desktop\qoritex\techcompany\resources\views/admin/services/index.blade.php ENDPATH**/ ?>