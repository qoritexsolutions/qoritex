

<?php $__env->startSection('title', 'Messages'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .filter-tabs {
        display: flex;
        gap: 0.5rem;
        margin-bottom: 1.5rem;
    }
    .filter-tab {
        padding: 0.5rem 1rem;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 50px;
        color: var(--gray-light);
        text-decoration: none;
        font-size: 0.9rem;
        transition: all 0.3s ease;
    }
    .filter-tab:hover,
    .filter-tab.active {
        background: var(--primary);
        border-color: var(--primary);
        color: var(--white);
    }
    .message-row {
        cursor: pointer;
    }
    .message-row:hover {
        background: rgba(99, 102, 241, 0.05) !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>Contact Messages</h2>
    </div>
    <div class="card-body">
        <div class="filter-tabs">
            <a href="<?php echo e(route('admin.messages.index')); ?>" class="filter-tab <?php echo e(!request('status') ? 'active' : ''); ?>">All</a>
            <a href="<?php echo e(route('admin.messages.index', ['status' => 'new'])); ?>" class="filter-tab <?php echo e(request('status') == 'new' ? 'active' : ''); ?>">New</a>
            <a href="<?php echo e(route('admin.messages.index', ['status' => 'read'])); ?>" class="filter-tab <?php echo e(request('status') == 'read' ? 'active' : ''); ?>">Read</a>
            <a href="<?php echo e(route('admin.messages.index', ['status' => 'replied'])); ?>" class="filter-tab <?php echo e(request('status') == 'replied' ? 'active' : ''); ?>">Replied</a>
        </div>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Status</th>
                        <th>From</th>
                        <th>Subject</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="message-row" onclick="showMessage(<?php echo e($message->id); ?>)">
                        <td>
                            <span class="badge badge-<?php echo e($message->status === 'new' ? 'warning' : ($message->status === 'read' ? 'primary' : 'success')); ?>">
                                <?php echo e(ucfirst($message->status)); ?>

                            </span>
                        </td>
                        <td>
                            <div>
                                <strong><?php echo e($message->name); ?></strong>
                                <div style="font-size: 0.85rem; color: var(--gray);"><?php echo e($message->email); ?></div>
                            </div>
                        </td>
                        <td><?php echo e($message->subject); ?></td>
                        <td style="color: var(--gray);"><?php echo e($message->created_at->format('M d, Y h:i A')); ?></td>
                        <td onclick="event.stopPropagation()">
                            <div class="actions">
                                <?php if($message->status === 'new'): ?>
                                <form action="<?php echo e(route('admin.messages.update-status', $message)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="read">
                                    <button type="submit" class="action-btn" title="Mark as Read">
                                        <i class="fas fa-check"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                                <form action="<?php echo e(route('admin.messages.destroy', $message)); ?>" method="POST" onsubmit="return confirm('Are you sure?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="action-btn delete" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" style="text-align: center; color: var(--gray); padding: 3rem;">
                            No messages found.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($messages->hasPages()): ?>
        <div class="pagination"><?php echo e($messages->links()); ?></div>
        <?php endif; ?>
    </div>
</div>

<!-- Message Modal -->
<div id="messageModal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.8); z-index: 1000; align-items: center; justify-content: center;">
    <div style="background: var(--dark-light); border-radius: var(--radius); max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto;">
        <div style="padding: 1.5rem; border-bottom: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between;">
            <h3 id="modalSubject">Subject</h3>
            <button onclick="closeModal()" style="background: none; border: none; color: var(--gray); font-size: 1.5rem; cursor: pointer;">&times;</button>
        </div>
        <div style="padding: 1.5rem;">
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 1rem; margin-bottom: 1.5rem;">
                <div><strong style="color: var(--gray-light);">From:</strong> <span id="modalName"></span></div>
                <div><strong style="color: var(--gray-light);">Email:</strong> <span id="modalEmail"></span></div>
                <div><strong style="color: var(--gray-light);">Phone:</strong> <span id="modalPhone"></span></div>
                <div><strong style="color: var(--gray-light);">Date:</strong> <span id="modalDate"></span></div>
            </div>
            <div style="background: rgba(15,23,42,0.5); padding: 1.5rem; border-radius: var(--radius);">
                <p id="modalMessage" style="line-height: 1.8;"></p>
            </div>
            <div style="margin-top: 1.5rem; display: flex; gap: 1rem;">
                <a id="replyLink" href="" class="btn btn-primary"><i class="fas fa-reply"></i> Reply via Email</a>
                <button onclick="closeModal()" class="btn btn-secondary">Close</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
const messages = <?php echo json_encode($messages->items(), 15, 512) ?>;

function showMessage(id) {
    const message = messages.find(m => m.id === id);
    if (!message) return;
    
    document.getElementById('modalSubject').textContent = message.subject;
    document.getElementById('modalName').textContent = message.name;
    document.getElementById('modalEmail').textContent = message.email;
    document.getElementById('modalPhone').textContent = message.phone || 'N/A';
    document.getElementById('modalDate').textContent = new Date(message.created_at).toLocaleString();
    document.getElementById('modalMessage').textContent = message.message;
    document.getElementById('replyLink').href = 'mailto:' + message.email + '?subject=Re: ' + message.subject;
    
    document.getElementById('messageModal').style.display = 'flex';
}

function closeModal() {
    document.getElementById('messageModal').style.display = 'none';
}

document.getElementById('messageModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\qorit\Desktop\qoritex\techcompany\resources\views/admin/messages/index.blade.php ENDPATH**/ ?>