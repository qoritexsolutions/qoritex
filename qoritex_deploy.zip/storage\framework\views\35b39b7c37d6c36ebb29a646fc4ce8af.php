

<?php $__env->startSection('title', 'Team Members'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>All Team Members</h2>
        <a href="<?php echo e(route('admin.team.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Add Member
        </a>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Order</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div style="width: 50px; height: 50px; background: var(--gradient-primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                                <?php if($member->photo): ?>
                                <img src="<?php echo e(asset('storage/' . $member->photo)); ?>" alt="<?php echo e($member->name); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                                <?php else: ?>
                                <i class="fas fa-user" style="color: white;"></i>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td><strong><?php echo e($member->name); ?></strong></td>
                        <td><?php echo e($member->position); ?></td>
                        <td><?php echo e($member->order); ?></td>
                        <td>
                            <span class="badge badge-<?php echo e($member->is_active ? 'success' : 'danger'); ?>">
                                <?php echo e($member->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td>
                            <div class="actions">
                                <a href="<?php echo e(route('admin.team.edit', $member)); ?>" class="action-btn" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.team.destroy', $member)); ?>" method="POST" onsubmit="return confirm('Are you sure?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="action-btn delete" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--gray); padding: 3rem;">
                            No team members found. <a href="<?php echo e(route('admin.team.create')); ?>">Add your first member</a>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($teamMembers->hasPages()): ?>
        <div class="pagination"><?php echo e($teamMembers->links()); ?></div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\qorit\Desktop\qoritex\techcompany\resources\views/admin/team/index.blade.php ENDPATH**/ ?>