

<?php $__env->startSection('title', 'Projects'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>All Projects</h2>
        <a href="<?php echo e(route('admin.projects.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Add Project
        </a>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Featured</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div style="width: 80px; height: 50px; background: var(--gradient-primary); border-radius: 8px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                                <?php if($project->image): ?>
                                <img src="<?php echo e(asset('storage/' . $project->image)); ?>" alt="<?php echo e($project->title); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                                <?php else: ?>
                                <i class="fas fa-image" style="color: rgba(255,255,255,0.3);"></i>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td><strong><?php echo e($project->title); ?></strong></td>
                        <td><?php echo e($project->category ?? '-'); ?></td>
                        <td>
                            <?php if($project->is_featured): ?>
                            <span class="badge badge-warning"><i class="fas fa-star"></i> Featured</span>
                            <?php else: ?>
                            -
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge badge-<?php echo e($project->is_active ? 'success' : 'danger'); ?>">
                                <?php echo e($project->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td>
                            <div class="actions">
                                <a href="<?php echo e(route('admin.projects.edit', $project)); ?>" class="action-btn" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.projects.destroy', $project)); ?>" method="POST" onsubmit="return confirm('Are you sure?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="action-btn delete" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--gray); padding: 3rem;">
                            No projects found. <a href="<?php echo e(route('admin.projects.create')); ?>">Add your first project</a>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($projects->hasPages()): ?>
        <div class="pagination"><?php echo e($projects->links()); ?></div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\qorit\Desktop\qoritex\techcompany\resources\views/admin/projects/index.blade.php ENDPATH**/ ?>