

<?php $__env->startSection('title', 'Add Project'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>Add New Project</h2>
        <a href="<?php echo e(route('admin.projects.index')); ?>" class="btn btn-secondary btn-sm">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.projects.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-group">
                    <label for="title">Title *</label>
                    <input type="text" id="title" name="title" class="form-control" value="<?php echo e(old('title')); ?>" required>
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p style="color: var(--danger); font-size: 0.85rem;"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="category">Category</label>
                    <input type="text" id="category" name="category" class="form-control" value="<?php echo e(old('category')); ?>" placeholder="e.g., Web Development">
                </div>
            </div>

            <div class="form-group">
                <label for="description">Description *</label>
                <textarea id="description" name="description" class="form-control" rows="5" required><?php echo e(old('description')); ?></textarea>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="client">Client</label>
                    <input type="text" id="client" name="client" class="form-control" value="<?php echo e(old('client')); ?>">
                </div>
                <div class="form-group">
                    <label for="url">Project URL</label>
                    <input type="url" id="url" name="url" class="form-control" value="<?php echo e(old('url')); ?>">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="image">Image</label>
                    <input type="file" id="image" name="image" class="form-control" accept="image/*">
                </div>
                <div class="form-group">
                    <label for="completed_at">Completion Date</label>
                    <input type="date" id="completed_at" name="completed_at" class="form-control" value="<?php echo e(old('completed_at')); ?>">
                </div>
            </div>

            <div class="form-group">
                <label for="technologies">Technologies (comma-separated)</label>
                <input type="text" id="technologies" name="technologies" class="form-control" value="<?php echo e(old('technologies')); ?>" placeholder="Laravel, Vue.js, MySQL">
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-check">
                        <input type="checkbox" name="is_featured" value="1" <?php echo e(old('is_featured') ? 'checked' : ''); ?>>
                        Featured project
                    </label>
                </div>
                <div class="form-group">
                    <label class="form-check">
                        <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', true) ? 'checked' : ''); ?>>
                        Active (visible on website)
                    </label>
                </div>
            </div>

            <div style="display: flex; gap: 1rem;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Project</button>
                <a href="<?php echo e(route('admin.projects.index')); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\qorit\Desktop\qoritex\techcompany\resources\views/admin/projects/create.blade.php ENDPATH**/ ?>