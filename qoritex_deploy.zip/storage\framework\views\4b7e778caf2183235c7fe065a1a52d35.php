

<?php $__env->startSection('title', 'Testimonials'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h2>All Testimonials</h2>
        <a href="<?php echo e(route('admin.testimonials.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Add Testimonial
        </a>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Client</th>
                        <th>Company</th>
                        <th>Rating</th>
                        <th>Content</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 0.75rem;">
                                <div style="width: 40px; height: 40px; background: var(--gradient-primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                                    <?php if($testimonial->client_photo): ?>
                                    <img src="<?php echo e(asset('storage/' . $testimonial->client_photo)); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                                    <?php else: ?>
                                    <i class="fas fa-user" style="color: white;"></i>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <strong><?php echo e($testimonial->client_name); ?></strong>
                                    <div style="font-size: 0.85rem; color: var(--gray);"><?php echo e($testimonial->client_position); ?></div>
                                </div>
                            </div>
                        </td>
                        <td><?php echo e($testimonial->client_company ?? '-'); ?></td>
                        <td>
                            <span style="color: #fbbf24;">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                <i class="fas fa-star<?php echo e($i <= $testimonial->rating ? '' : '-o'); ?>"></i>
                                <?php endfor; ?>
                            </span>
                        </td>
                        <td><?php echo e(Str::limit($testimonial->content, 50)); ?></td>
                        <td>
                            <span class="badge badge-<?php echo e($testimonial->is_active ? 'success' : 'danger'); ?>">
                                <?php echo e($testimonial->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td>
                            <div class="actions">
                                <a href="<?php echo e(route('admin.testimonials.edit', $testimonial)); ?>" class="action-btn" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('admin.testimonials.destroy', $testimonial)); ?>" method="POST" onsubmit="return confirm('Are you sure?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="action-btn delete" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--gray); padding: 3rem;">
                            No testimonials found. <a href="<?php echo e(route('admin.testimonials.create')); ?>">Add your first testimonial</a>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($testimonials->hasPages()): ?>
        <div class="pagination"><?php echo e($testimonials->links()); ?></div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\qorit\Desktop\qoritex\techcompany\resources\views/admin/testimonials/index.blade.php ENDPATH**/ ?>